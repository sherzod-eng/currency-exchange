<?php
$this->title = 'Currency exchange';
?>
<div class="col-md-4 col-md-offset-4 blok">
	<h3>Currency exchange:</h3>
	<label>You pay</label><br>
	<select class="select-form" id="typeMoney1">
		<option>Type</option>
		<option>CAD</option>
		<option>HKD</option>
		<option>ISK</option>
		<option>PHP</option>
		<option>DKK</option>
		<option>HUF</option>
		<option>CZK</option>
		<option>GBP</option>
		<option>RON</option>
		<option>IDR</option>
		<option>INR</option>
		<option>BRL</option>
		<option>RUB</option>
		<option>HRK</option>
		<option>JPY</option>
		<option>THB</option>
		<option>CHF</option>
		<option>EUR</option>
		<option>MYR</option>
		<option>BGN</option>
		<option>TRY</option>
		<option>CNY</option>
		<option>NOK</option>
		<option>NZD</option>
		<option>ZAR</option>
		<option>USD</option>
		<option>MXN</option>
		<option>SGD</option>
		<option>AUD</option>
		<option>ILS</option>
		<option>KRW</option>
		<option>PLN</option>
	</select>
	<input id="totalMoney1" type="number" class="inputs" placeholder="Amount of money"  disabled>
	<input id="infoPhp" type="text" class="inputInfo" name="" disabled placeholder="Exchange rate"><br>
	<label>Go Media will get</label><br>
	<select class="select-form" id="typeMoney2">
		<option>Type</option>
		<option>CAD</option>
		<option>HKD</option>
		<option>ISK</option>
		<option>PHP</option>
		<option>DKK</option>
		<option>HUF</option>
		<option>CZK</option>
		<option>GBP</option>
		<option>RON</option>
		<option>IDR</option>
		<option>INR</option>
		<option>BRL</option>
		<option>RUB</option>
		<option>HRK</option>
		<option>JPY</option>
		<option>THB</option>
		<option>CHF</option>
		<option>EUR</option>
		<option>MYR</option>
		<option>BGN</option>
		<option>TRY</option>
		<option>CNY</option>
		<option>NOK</option>
		<option>NZD</option>
		<option>ZAR</option>
		<option>USD</option>
		<option>MXN</option>
		<option>SGD</option>
		<option>AUD</option>
		<option>ILS</option>
		<option>KRW</option>
		<option>PLN</option>
	</select>
	<input id="totalMoney2" type="number" class="inputs" placeholder="The resulting money" disabled="">
</div>



