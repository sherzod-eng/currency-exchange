
	//This is JavaScript;
	$('#select').on('change', function(){
		if($(this).val() != 'Type') document.getElementById('money_1').removeAttribute('disabled');
		else document.getElementById('money_1').setAttribute('disabled', 'disabled');

	})

	$('#select2').on('change', function(){
		if($(this).val() != 'Type' && $('#select').val() != 'Type' && $('#money_1').val() > 0){
		var base = $('#select').val();
		var total = $('#money_1').val();
		var moneyType = $('#select2').val();
			$.ajax({
				url: 'https://api.exchangeratesapi.io/latest',
				type: 'GET',
				data: {base: base},
				dataType: 'json',
				success: function(res)
				{
					var ans = total * (res['rates'][moneyType]);
					$('#infoJs').val(res['rates'][moneyType]);
					 $('#money_2').val(ans);
					
				},
				error: function()
				{
					alert('net::ERR_INTERNET_DISCONNECTED');
				}
			})
		}
	})

	$('#money_1').on('keyup', function(){
		if($('#select').val() != 'Type' && $('#select2').val() != 'Type' && $(this).val() > 0){
		var base = $('#select').val();
		var total = $('#money_1').val();
		var moneyType = $('#select2').val();
			$.ajax({
				url: 'https://api.exchangeratesapi.io/latest',
				type: 'GET',
				data: {base: base},
				dataType: 'json',
				success: function(res){
					var ans = total * (res['rates'][moneyType]);
					$('#infoJs').val(res['rates'][moneyType]);
					 $('#money_2').val(ans);
					
				},
				error: function()
				{
					alert('net::ERR_INTERNET_DISCONNECTED');
				}
			})
		}
	})

	$('#select').on('change', function(){
		if($('#money_2').val() != ''){
		var base = $('#select').val();
		var total = $('#money_1').val();
		var moneyType = $('#select2').val();
			$.ajax({
				url: 'https://api.exchangeratesapi.io/latest',
				type: 'GET',
				data: {base: base},
				dataType: 'json',
				success: function(res){
					var ans = total * (res['rates'][moneyType]);
					$('#infoJs').val(res['rates'][moneyType]);
					 $('#money_2').val(ans);
					
				},
				error: function()
				{
					alert('net::ERR_INTERNET_DISCONNECTED');
				}
			})
		}
	})


	//This is PhP and ajax request;
	$('#typeMoney1').on('change', function(){
		if($(this).val() != 'Type') document.getElementById('totalMoney1').removeAttribute('disabled');
		else document.getElementById('totalMoney1').setAttribute('disabled', 'disabled');

	})
	$('#typeMoney2').on('change', function(){
		if ($(this).val() != 'Type' && $('#typeMoney1').val() != 'Type' && $('#totalMoney1').val() > 0) {
		var typeMoney1 = $('#typeMoney1').val();
		var typeMoney2 = $('#typeMoney2').val();
		var totalMoney1 = $('#totalMoney1').val();
		$.ajax({
			url: '/site/ajax',
			type: 'GET',
			data: {
				typeMoney1: typeMoney1,
				typeMoney2: typeMoney2,
				totalMoney1: totalMoney1,
			},
			dataType: 'json',
			beforeSend: function()
			{
				$('#totalMoney2').html('Loading...');
				//$('.blocPhp').html('Loading...');
			},
			success: function(res)
			{
				var info = res/totalMoney1;
				$('#totalMoney2').val(res);
				$('#infoPhp').val(info);
			},
			error: function()
			{
				alert('net::ERR_INTERNET_DISCONNECTED');
			}

		})
	   }
	})
	
	$('#typeMoney1').on('change', function(){
		if($('#totalMoney2').val() != ''){
		var typeMoney1 = $('#typeMoney1').val();
		var typeMoney2 = $('#typeMoney2').val();
		var totalMoney1 = $('#totalMoney1').val();
		$.ajax({
			url: '/site/ajax',
			type: 'GET',
			data: {
				typeMoney1: typeMoney1,
				typeMoney2: typeMoney2,
				totalMoney1: totalMoney1,
			},
			dataType: 'json',
			beforeSend: function()
			{
				$('.blocPhp').html('Loading...');
			},
			success: function(res)
			{
				var info = res/totalMoney1;
				$('#totalMoney2').val(res);
				$('#infoPhp').val(info);
			},
			error: function()
			{
				alert('net::ERR_INTERNET_DISCONNECTED');
			}

		})
	}
	})
	$('#totalMoney1').on('keyup', function(){
		if($('#typeMoney1').val() != '' && $('#typeMoney2').val() != 'Type' && $(this).val() > 0){
		var typeMoney1 = $('#typeMoney1').val();
		var typeMoney2 = $('#typeMoney2').val();
		var totalMoney1 = $('#totalMoney1').val();
		$.ajax({
			url: '/site/ajax',
			type: 'GET',
			data: {
				typeMoney1: typeMoney1,
				typeMoney2: typeMoney2,
				totalMoney1: totalMoney1,
			},
			dataType: 'json',
			beforeSend: function()
			{
				$('.blocPhp').html('Loading...');
			},
			success: function(res)
			{	
				var info = res/totalMoney1;
				$('#totalMoney2').val(res);
				$('#infoPhp').val(info);
			},
			error: function()
			{
				alert('net::ERR_INTERNET_DISCONNECTED');
			}

		})
	  }
	})


