<?php

namespace frontend\Models;

use Yii;
use yii\base\Model;
/**
 * 
 */
class Exchange extends Model
{
	
	public function getExchange($typeMoney1, $typeMoney2, $totalMoney1)
	{
		$ch = curl_init();
        $url = "https://api.exchangeratesapi.io/latest?base=".$typeMoney1;

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);

        if($e = curl_error($ch)){
            echo $e;
        }
        else
        {
             $decode = json_decode($result, true);
             $ans = $decode['rates'][$typeMoney2] * $totalMoney1;
             return $ans;
            
        }

        curl_close($ch);
	}
}